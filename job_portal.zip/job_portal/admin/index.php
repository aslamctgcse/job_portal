<?php

echo 'You can not access this page';

?>